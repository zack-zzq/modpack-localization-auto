---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME无限元件
    icon: expatternprovider:infinity_cell
categories:
- extended items
item_ids:
- expatternprovider:infinity_cell
---

# ME无限元件

采用存储元件形式的简易无限水源/圆石存储装置。

<Row>
<ItemImage id="expatternprovider:infinity_cell" scale="4"></ItemImage>
</Row>

该元件具有21亿物品/流体的存储容量，支持以下操作：
- 可从中提取无限量的圆石或水源
- 可向其注入无限量的圆石或水源