---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 设备
  icon: interface
---

# 设备

**设备**指的是对网络本身进行操作的AE2组件。它们几乎都需要占用频道，除了[标准发信器](../items-blocks-machines/level_emitter.md)这一反例。

以下是一些设备：

*   <ItemLink id="interface" />
*   <ItemLink id="import_bus" />
*   <ItemLink id="storage_bus" />
*   <ItemLink id="pattern_provider" />
*   <ItemLink id="drive" />
