---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 赛特斯石英粉
  icon: certus_quartz_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_dust
---

# 赛特斯石英粉

<ItemImage id="certus_quartz_dust" scale="4" />

由<ItemLink id="certus_quartz_crystal" />经<ItemLink id="inscriber" />粉碎制成。用于生产多种AE2材料和组件。

## 合成配方

<RecipeFor id="certus_quartz_dust" />