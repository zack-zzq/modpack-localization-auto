// priority: 0

StartupEvents.registry("fluid", (event) => {
  event.create("molten_nether_quartz").thickTexture(0xfbdbd9).bucketColor(0xfbdbd9).displayName(Text.translate('kubejs.startup.fluids.1'));
  event.create("molten_copper").thickTexture(0xdd7357).bucketColor(0xdd7357).displayName(Text.translate('kubejs.startup.fluids.2'));
  event.create("molten_iron").thickTexture(0xa62c2b).bucketColor(0xa62c2b).displayName(Text.translate('kubejs.startup.fluids.3'));
  event.create("molten_zinc").thickTexture(0x9e9e9e).bucketColor(0x9e9e9e).displayName(Text.translate('kubejs.startup.fluids.4'));
  event.create("molten_brass").thickTexture(0xf0d9a5).bucketColor(0xf0d9a5).displayName(Text.translate('kubejs.startup.fluids.5'));
  event.create("molten_desh").thickTexture(0x9e4539).bucketColor(0x9e4539).displayName(Text.translate('kubejs.startup.fluids.6'));
  event.create("sulfuric_heavy_oil").thickTexture(0x5f5a4b).bucketColor(0x5f5a4b).displayName(Text.translate('kubejs.startup.fluids.7'));
  event.create("molten_ostrum").thickTexture(0xbf7a82).bucketColor(0xbf7a82).displayName(Text.translate('kubejs.startup.fluids.8'));
  event.create("molten_calorite").thickTexture(0xcb4e4f).bucketColor(0xcb4e4f).displayName(Text.translate('kubejs.startup.fluids.9'));
  event.create("molten_gold").thickTexture(0xf3d000).bucketColor(0xf3d000).displayName(Text.translate('kubejs.startup.fluids.10'));
  event.create("molten_netherite").thickTexture(0x4f4f4f).bucketColor(0x4f4f4f).displayName(Text.translate('kubejs.startup.fluids.11'));
  event.create("molten_deorum").thickTexture(0xffda8b).bucketColor(0xffda8b).displayName(Text.translate('kubejs.startup.fluids.12'));
  event.create("molten_obsidian").thickTexture(0x2f1434).bucketColor(0x2f1434).displayName(Text.translate('kubejs.startup.fluids.13'));
  event.create("molten_prosperity").thickTexture(0x9bbec1).bucketColor(0x9bbec1).displayName(Text.translate('kubejs.startup.fluids.14'));
  event.create("molten_diamond").thickTexture(0x25ebec).bucketColor(0x25ebec).displayName(Text.translate('kubejs.startup.fluids.15'));
  event.create("molten_emerald").thickTexture(0x2cc879).bucketColor(0x2cc879).displayName(Text.translate('kubejs.startup.fluids.16'));
  event.create("molten_lapis").thickTexture(0x2c5cc8).bucketColor(0x2c5cc8).displayName(Text.translate('kubejs.startup.fluids.17'));
  event.create("molten_redstone").thickTexture(0xc82c2c).bucketColor(0xc82c2c).displayName(Text.translate('kubejs.startup.fluids.18'));
  event.create("molten_signalum").thickTexture(0xff3400).bucketColor(0xff3400).displayName(Text.translate('kubejs.startup.fluids.19'));
  event.create("molten_lumium").thickTexture(0xfeec89).bucketColor(0xfeec89).displayName(Text.translate('kubejs.startup.fluids.20'));
  event.create("molten_enderium").thickTexture(0x4584de).bucketColor(0x4584de).displayName(Text.translate('kubejs.startup.fluids.21'));
  event.create("molten_tin").thickTexture(0xa5e2e5).bucketColor(0xa5e2e5).displayName(Text.translate('kubejs.startup.fluids.22'));
  event.create("molten_lead").thickTexture(0x4c5d7f).bucketColor(0x4c5d7f).displayName(Text.translate('kubejs.startup.fluids.23'));
  event.create("molten_silver").thickTexture(0xadbfc2).bucketColor(0xadbfc2).displayName(Text.translate('kubejs.startup.fluids.24'));
  event.create("molten_nickel").thickTexture(0xd3ccac).bucketColor(0xd3ccac).displayName(Text.translate('kubejs.startup.fluids.25'));
  event.create("molten_electrum").thickTexture(0xf0e9b5).bucketColor(0xf0e9b5).displayName(Text.translate('kubejs.startup.fluids.26'));
  event.create("molten_invar").thickTexture(0xa4afad).bucketColor(0xa4afad).displayName(Text.translate('kubejs.startup.fluids.27'));
  event.create("molten_constantan").thickTexture(0xf2bf79).bucketColor(0xf2bf79).displayName(Text.translate('kubejs.startup.fluids.28'));
  event.create("molten_pendorite").thickTexture(0x35226c).bucketColor(0x35226c).displayName(Text.translate('kubejs.startup.fluids.29'));
});
